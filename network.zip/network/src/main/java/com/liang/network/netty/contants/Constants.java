package com.liang.network.netty.contants;

public class Constants {

  public static final boolean loop = true;
  
  public static final boolean hasDecodePlugin = true;

  public static final String lineSeparator = System.getProperty("line.separator");

  public static final String QUERY_TIME_ORDER = "QUERY TIME ORDER";

}
