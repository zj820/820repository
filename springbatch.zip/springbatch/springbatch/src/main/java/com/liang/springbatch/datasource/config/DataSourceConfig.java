package com.liang.springbatch.datasource.config;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;

//@Configuration
public class DataSourceConfig {
  
  @Bean(name = "H2DataSource")
  public DataSource getDataSource() {
    return DataSourceBuilder.create()
    .driverClassName("org.h2.Driver")
    .username("sa")
    .type(org.h2.jdbcx.JdbcDataSource.class)
    .url("jdbc:h2:file:D:\\testdb").build();
  }

}
