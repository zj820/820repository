package com.liang.springbatch.constants;

public class Constant {
  
  public static final boolean THROW_EXCEPTION = false; //抛出异常

}
