package com.liang.network.nio.chat;

import java.io.IOException;
import java.util.Scanner;

/**
 * non-bloking server
 * 
 * @author viruser
 *
 */
public class NClient {

  public static void main(String[] args) {
    try {
      NClientTask client = new NClientTask("10.10.20.162", 8888);
      new Thread(client).start();
      Scanner scanner = new Scanner(System.in);
      System.out.println("please type your name:");
      String name = scanner.nextLine();
      client.setName(name);
      while (true) {
        String message = scanner.nextLine();
        if ("quit".equals(message)) {
          client.stop();
          break;
        } else {
          client.addMessage(message);
        }
      }
      scanner.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
