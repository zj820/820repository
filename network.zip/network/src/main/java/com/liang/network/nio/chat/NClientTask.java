package com.liang.network.nio.chat;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class NClientTask implements Runnable {

  Selector selector;
  SocketChannel socketChannel;
  String host;
  int port;
  private volatile boolean stop = false;
  private BlockingQueue<String> messageQueue = new LinkedBlockingQueue<String>();
  String name;

  public NClientTask(String host, int port) throws IOException {
    this.host = host;
    this.port = port;
    init();
  }

  private void init() throws IOException {
    selector = Selector.open();
    socketChannel = SocketChannel.open();
    socketChannel.configureBlocking(false);
    doConnect();
  }

  public void stop() {
    stop = true;
  }

  public void addMessage(String message) {
    try {
      messageQueue.put(message);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  @Override
  public void run() {
    while (!stop) {
      try {
        while (!messageQueue.isEmpty()) {
          String poll = messageQueue.poll();
          if (poll != null) {
            doWrite(socketChannel, poll);
          }
        }
        int i = selector.select(1000);
        if (i <= 0) {
          continue;
        }
        Set<SelectionKey> selectionKeys = selector.selectedKeys();
        Iterator<SelectionKey> iter = selectionKeys.iterator();
        SelectionKey key = null;
        while (iter.hasNext()) {
          key = iter.next();
          iter.remove();
          handleKey(key);
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    if (selector != null) {
      try {
        socketChannel.close();
        selector.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  private void handleKey(SelectionKey key) throws IOException {
    if (!key.isValid()) {
      return;
    }

    SocketChannel socketChannel = (SocketChannel) key.channel();
    if (key.isConnectable()) {
      if (socketChannel.finishConnect()) {
        socketChannel.register(selector, SelectionKey.OP_READ);
        System.out.println("connect to server success!!!");
      } else {
        System.exit(1);
      }
    }

    if (key.isReadable()) {
      ByteBuffer buffer = ByteBuffer.allocate(1024);
      int readBytes = socketChannel.read(buffer);
      if (readBytes > 0) {
        buffer.flip();
        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);
        String body = new String(bytes, "utf-8");
        System.out.println(body);
      }
    }
  }

  private void doWrite(SocketChannel socketChannel, String response) throws IOException {
    if (response != null && response.length() > 0) {
      byte[] bytes = response.toLowerCase().getBytes();
      ByteBuffer buffer = ByteBuffer.allocate(bytes.length);
      buffer.put(bytes);
      buffer.flip();
      socketChannel.write(buffer);
    }
  }

  private void doConnect() throws IOException {
    System.out.println("connecting to server......");
    if (socketChannel.connect(new InetSocketAddress(host, port))) {
      System.out.println("connected to server");
      socketChannel.register(selector, SelectionKey.OP_READ);
    } else {
      System.out.println("connecting to server failed");
      socketChannel.register(selector, SelectionKey.OP_CONNECT);
    }
  }

  public void setName(String name) {
    this.name = name;
  }
}
