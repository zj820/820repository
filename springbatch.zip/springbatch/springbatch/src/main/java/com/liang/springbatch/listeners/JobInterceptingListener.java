package com.liang.springbatch.listeners;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

@Component
public class JobInterceptingListener implements JobExecutionListener {
  
  Logger logger = LoggerFactory.getLogger(JobInterceptingListener.class);

  @Override
  public void beforeJob(JobExecution jobExecution) {
    logger.info("start executing job " + jobExecution.getJobInstance().getJobName());
  }

  @Override
  public void afterJob(JobExecution jobExecution) {
    logger.info("finished executing job " + jobExecution.getJobInstance().getJobName() + " with status " + jobExecution.getStatus());
    logger.info("timecost:" + (jobExecution.getEndTime().getTime() - jobExecution.getCreateTime().getTime()) + "ms");
  }

}
