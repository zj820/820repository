package com.liang.springbatch.executor;

import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

@Component
public class ExecutorFactory {
  
  @Bean
  ThreadPoolTaskExecutor getTaskExecutor() {
    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(10);
    executor.setMaxPoolSize(15);
    executor.setKeepAliveSeconds(600);
    executor.setQueueCapacity(1000);
    executor.setThreadNamePrefix("job-");
    executor.initialize();
    
    return executor;
  }

}
