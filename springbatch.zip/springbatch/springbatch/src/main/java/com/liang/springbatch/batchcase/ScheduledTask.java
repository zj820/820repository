package com.liang.springbatch.batchcase;

import java.util.Date;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

//@Configuration
public class ScheduledTask {
  
  @Autowired
  Job job;
  
  @Autowired
  JobLauncher jobLauncher;
  
  @Scheduled(cron = "0/10 * * * * ?")
  public void run() throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
    jobLauncher.run(  
        job,  
        new JobParametersBuilder()  
        .addDate("date", new Date())  
        .toJobParameters()  
    );  
  }

}
