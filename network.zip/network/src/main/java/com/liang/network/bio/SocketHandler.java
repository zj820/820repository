package com.liang.network.bio;

import java.net.Socket;

public interface SocketHandler {

  public void handle(Socket socket);

}
