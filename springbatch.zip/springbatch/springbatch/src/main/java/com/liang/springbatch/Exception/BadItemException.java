package com.liang.springbatch.Exception;

public class BadItemException extends Exception {
  
  /**
   * 
   */
  private static final long serialVersionUID = -1071640419039193829L;

  public BadItemException() {
    
  }
  
  public BadItemException(String item) {
    super(item + " is bad item");
  }

}
