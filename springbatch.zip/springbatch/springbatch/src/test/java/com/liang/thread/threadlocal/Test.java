package com.liang.thread.threadlocal;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.alibaba.ttl.TransmittableThreadLocal;
import com.alibaba.ttl.TtlRunnable;

public class Test {
  
  public static void main(String[] args) {
    InheritableThreadLocalContext context = new InheritableThreadLocalContext();
    context.setContext("iam fucking high");
    System.out.println("inheritableFatherThread:" + context.getContext());
    
    new Thread(new Runnable() {
      @Override
      public void run() {
        System.out.println("inheritableChildThread " + context.getContext());
      }
    }).start(); 
    
    ThreadLocalContext context2 = new ThreadLocalContext();
    System.out.println("fatherThread:" + context2.getContext());
    
    new Thread(new Runnable() {
      @Override
      public void run() {
        System.out.println("childThread: " + context2.getContext());
      }
    }).start(); 
    
    ExecutorService executor = Executors.newFixedThreadPool(2);
    for (int i = 0; i < 5; i++) {
      executor.submit(new Runnable() {
        @Override
        public void run() {
          System.out.println("threadpool " + context.getContext());
        }
      });
    }
    
    context.setContext("iam fucking even higher");
    for (int i = 0; i < 5; i++) {
      executor.submit(new Runnable() {
        @Override
        public void run() {
          System.out.println("threadpool " + context.getContext());
        }
      });
    }
    
    TransmittableThreadLocal<String> parent = new TransmittableThreadLocal<String>();
    parent.set("value-set-in-parent");

    Runnable task = new Runnable() {

      @Override
      public void run() {
        System.out.println(parent.get());
      }
      
    };
    // 额外的处理，生成修饰了的对象ttlRunnable
    for (int i = 0; i < 5; i++) {
      executor.submit(TtlRunnable.get(new Runnable() {
        @Override
        public void run() {
          System.out.println("ttl"  + parent.get());
        }
      }));
    }
    // =====================================================
    // Task中可以读取，值是"value-set-in-parent"
    String value = parent.get();
    System.out.println(value);

    parent.set("iam really high");
    // 额外的处理，生成修饰了的对象ttlRunnable
    for (int i = 0; i < 5; i++) {
      executor.submit(TtlRunnable.get(new Runnable() {
        @Override
        public void run() {
          System.out.println("ttl2"  + parent.get());
        }
      }));
    }
    // =====================================================
    // Task中可以读取，值是"value-set-in-parent"
    value = parent.get();
    System.out.println(value);
  }

}
