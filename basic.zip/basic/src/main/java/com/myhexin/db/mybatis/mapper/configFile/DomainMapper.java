package com.myhexin.db.mybatis.mapper.configFile;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.type.JdbcType;

import com.myhexin.db.mybatis.model.Domain;

@Mapper
public interface DomainMapper {

	@Select("select * from domainInfo")
	@Results({
		@Result(column="short_cut",property="domainShortCut",jdbcType=JdbcType.VARCHAR),
		@Result(column="index_prefix",property="domainIndexPrefix",jdbcType=JdbcType.VARCHAR),
		@Result(column="index_abs",property="domainWithAbs",jdbcType=JdbcType.VARCHAR)
	})
	public List<Domain> selectAll();
}
