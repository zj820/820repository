package com.myhexin.db.mybatis.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.myhexin.db.mybatis.mapper.configFile.DomainMapper;
import com.myhexin.db.mybatis.mapper.ontologydb.FieldMapper;

@Repository
public class FieldDao {

	@Autowired
	private FieldMapper fieldMapper;
	
	public int countFieldSize() {
		return fieldMapper.selectAll().size();
	}
}
