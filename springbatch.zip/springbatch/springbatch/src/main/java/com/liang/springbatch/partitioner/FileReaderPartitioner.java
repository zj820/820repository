package com.liang.springbatch.partitioner;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;

import com.liang.springbatch.bo.Stock;

//@Component
public class FileReaderPartitioner {
  
  @Bean
  @StepScope
  public FlatFileItemReader<Stock> partitionReader(@Value("#{stepExecutionContext['id']}") String id) {
      FlatFileItemReader<Stock> reader = new FlatFileItemReader<Stock>();
      String fileName = "stock.csv";
      fileName = "stock" + id + ".csv";
      reader.setResource(new ClassPathResource(fileName));
      reader.setLineMapper(new DefaultLineMapper<Stock>() {{
          setLineTokenizer(new DelimitedLineTokenizer() {{
              setNames(new String[] { "code", "name", "market" });
          }});
          setFieldSetMapper(new BeanWrapperFieldSetMapper<Stock>() {{
              setTargetType(Stock.class);
          }});
      }});
      return reader;
  }
}
