package com.liang.springbatch.bo;

public class StockRecommend {
  
  private Stock stock;
  private boolean recommand;
  private boolean testTime;
  
  public Stock getStock() {
    return stock;
  }
  public void setStock(Stock stock) {
    this.stock = stock;
  }
  public boolean isRecommand() {
    return recommand;
  }
  public void setRecommand(boolean recommand) {
    this.recommand = recommand;
  }
  public boolean isTestTime() {
    return testTime;
  }
  public void setTestTime(boolean testTime) {
    this.testTime = testTime;
  }
  
  

}
