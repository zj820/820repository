package com.myhexin.db.mybatis.mapper.ontologydb;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.type.JdbcType;

import com.myhexin.db.mybatis.model.Field;


@Mapper
public interface FieldMapper {

	@Select("select * from field")
	@Results({
		@Result(column="id",property="id",jdbcType=JdbcType.INTEGER),
		@Result(column="label",property="label",jdbcType=JdbcType.VARCHAR)
	})
	public List<Field> selectAll();
}
