package com.liang.network.netty.rpc;

import com.liang.network.netty.rpc.service.EntityService;
import com.liang.network.netty.rpc.service.Service;
import com.liang.network.netty.rpc.service.ServiceParameter;
import com.liang.network.netty.rpc.service.ServiceResult;

public class RpcClient {
  
  public static void main(String[] args) {
    Service service = RpcProxy.create(Service.class);
    String result = service.service("world");
    System.out.println(result);
    
    EntityService entityService = RpcProxy.create(EntityService.class);
    ServiceResult entityResult = entityService.service(new ServiceParameter("world"));
    System.out.println(entityResult);
  }

}
