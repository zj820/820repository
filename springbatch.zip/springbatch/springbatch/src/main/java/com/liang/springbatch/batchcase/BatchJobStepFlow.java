package com.liang.springbatch.batchcase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.liang.springbatch.Exception.BadItemException;
import com.liang.springbatch.bo.Stock;

@Component
public class BatchJobStepFlow {
  
  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  @Qualifier("jobInterceptingListener")
  JobExecutionListener jobExecutionListener;
  
  @Autowired
  ItemReader<Stock> reader;
  
  @Autowired
  ItemProcessor<Stock, Stock> processor;
  
  @Autowired
  ItemWriter<Stock> writer;
  
  @Bean(value = "helloWorldFlowJob")
  public Job buildHelloWorldFlowJob() {
    Job job = jobBuilderFactory.get("HelloWorldFlowJob")
              .incrementer(new RunIdIncrementer())
              .listener(jobExecutionListener)
              .start(flowstep1())
              .next(step2())
              .next(flowstep3())
              .build();
    return job;
  }
  
  @Bean(value = "helloWorldFlowJobCondition")
  public Job buildHelloWorldFlowJobCondition() {
    Job job = jobBuilderFactory.get("helloWorldFlowJobCondition")
              .incrementer(new RunIdIncrementer())
              .listener(jobExecutionListener)
              .start(flowstep1())
              .on("*").to(step2())
              .from(flowstep1()).on("failed").to(flowstep3())
              .end()
              .build();
    return job;
  }
  
  @Bean
  public Step flowstep1() {
      return stepBuilderFactory.get("flowJobStep1")
              .startLimit(2)
              .allowStartIfComplete(true)
              .tasklet(new TimeGetterTasklet())
              .build();
  }

  @Bean
  public Step step2() {
      return stepBuilderFactory.get("flowJobStep2")
              .startLimit(2)
              .allowStartIfComplete(true)
              .<Stock, Stock> chunk(10)
              .reader(reader)
              .processor(processor)
              .writer(writer)
              .faultTolerant()
//              .skipLimit(10)
//              .skip(BadItemException.class)
              .retryLimit(3)
              .retry(BadItemException.class)
              .build();
  }
  
  @Bean
  public Step flowstep3() {
      return stepBuilderFactory.get("flowJobStepLast")
              .startLimit(2)
              .allowStartIfComplete(true)
              .tasklet(new LastTasklet())
              .build();
  }
  
  public static class TimeGetterTasklet implements Tasklet {

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
      return RepeatStatus.FINISHED;
    }
    
  }
  
  public static class RecommendGetterTasklet implements Tasklet {

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
      return RepeatStatus.FINISHED;
    }
  }
  
  public static class LastTasklet implements Tasklet {

    Logger logger = LoggerFactory.getLogger(LastTasklet.class);
    
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
      logger.info("job finished!");
      return RepeatStatus.FINISHED;
    }
  }
}
