package com.liang.springbatch.batchcase;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.liang.springbatch.Exception.BadItemException;
import com.liang.springbatch.bo.Stock;
import com.liang.springbatch.constants.Constant;

@Component
public class BatchJobHelloWorld {
  
  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  @Qualifier("jobInterceptingListener")
  JobExecutionListener jobExecutionListener;
  
  @Autowired
  ThreadPoolTaskExecutor executor;
  
  @Bean(value = "helloWorldJob")
  public Job buildHelloWorldJob() {
    Job job = jobBuilderFactory.get("HelloWorldJob")
              .incrementer(new RunIdIncrementer())
              .listener(jobExecutionListener)
              .flow(step1())
              .end()
              .build();
    return job;
  }

  @Bean
  public Step step1() {
      return stepBuilderFactory.get("HelloWorldStep")
              .startLimit(2)
              .allowStartIfComplete(true)
              .<Stock, Stock> chunk(10)
              .reader(reader())
              .processor(processor())
              .writer(writer())
              .faultTolerant()
//              .skipLimit(10)
//              .skip(BadItemException.class)
//              .retryLimit(3)
//              .retry(BadItemException.class)
              .taskExecutor(executor)
              .build();
  }
  
  @Bean
  public FlatFileItemReader<Stock> reader() {
      FlatFileItemReader<Stock> reader = new FlatFileItemReader<Stock>();
      reader.setResource(new ClassPathResource("stock.csv"));
      reader.setLineMapper(new DefaultLineMapper<Stock>() {{
          setLineTokenizer(new DelimitedLineTokenizer() {{
              setNames(new String[] { "code", "name", "market" });
          }});
          setFieldSetMapper(new BeanWrapperFieldSetMapper<Stock>() {{
              setTargetType(Stock.class);
          }});
      }});
      return reader;
  }

  @Bean(name = "nameProcessor")
  public StockProcessor processor() {
      return new StockProcessor();
  }
  
  @Bean
  public StockWriter writer() {
      return new StockWriter();
  }
  
  public static class StockWriter implements ItemWriter<Stock> {
    
    private Logger logger = LoggerFactory.getLogger(StockWriter.class);
    
    @Override
    public void write(List<? extends Stock> items) throws Exception {
      logger.info("processd " + items.size() + " stock");
    }
  }
  
  public static class StockProcessor implements ItemProcessor<Stock, Stock> {
    
    private Logger logger = LoggerFactory.getLogger(StockProcessor.class);
    private boolean hasThrowException = false;
    
    @Override
    public Stock process(Stock stock) throws Exception {
      logger.info(stock.getCode());
      if (Constant.THROW_EXCEPTION ) { 
        if (!hasThrowException &&  "000301.SZ".equals(stock.getCode())) {
          hasThrowException = true;
          throw new BadItemException(stock.getCode()); 
        }
      }
      return stock;
    }
  }

}
