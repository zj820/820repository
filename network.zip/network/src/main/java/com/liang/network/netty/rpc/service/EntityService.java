package com.liang.network.netty.rpc.service;

public interface EntityService {
  
  public ServiceResult service(ServiceParameter parameter);

}
