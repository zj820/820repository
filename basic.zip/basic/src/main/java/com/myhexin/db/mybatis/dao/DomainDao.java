package com.myhexin.db.mybatis.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.myhexin.db.mybatis.mapper.configFile.DomainMapper;

@Repository
public class DomainDao {

	@Autowired
	private DomainMapper domainMapper;
	
	public int countDomainSize() {
		return domainMapper.selectAll().size();
	}
}
