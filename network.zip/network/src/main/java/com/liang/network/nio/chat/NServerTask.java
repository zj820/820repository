package com.liang.network.nio.chat;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class NServerTask implements Runnable {

  Selector selector;
  ServerSocketChannel serverSocketChannel;
  Map<String, SocketChannel> channelGroup = new ConcurrentHashMap<>();

  public NServerTask() throws IOException {
    selector = Selector.open();
    serverSocketChannel = ServerSocketChannel.open();
    serverSocketChannel.configureBlocking(false);
    serverSocketChannel.socket().bind(new InetSocketAddress(8888));
    serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
    System.out.println("server started......");
  }

  @Override
  public void run() {
    while (true) {
      try {
        int i = selector.select(1000);
        if (i <= 0) {
          continue;
        }
        Set<SelectionKey> selectionKeys = selector.selectedKeys();
        Iterator<SelectionKey> iter = selectionKeys.iterator();
        SelectionKey key = null;
        while (iter.hasNext()) {
          key = iter.next();
          iter.remove();
          handleKey(key);
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  private void handleKey(SelectionKey key) throws IOException {
    if (key.isAcceptable()) {
      handleAccept(key);
    } else if (key.isValid() && key.isReadable()) {
      SocketChannel socketChannel = (SocketChannel) key.channel();
      ByteBuffer buffer = ByteBuffer.allocate(1024);
      String remoteAddress = socketChannel.getRemoteAddress().toString();
      try {
        int readBytes = socketChannel.read(buffer);
        if (readBytes > 0) {
          buffer.flip();
          byte[] bytes = new byte[buffer.remaining()];
          buffer.get(bytes);
          String body = new String(bytes, "utf-8");
          System.out.println("the server receiced message " + body + " from" + socketChannel.getRemoteAddress());
          for (Entry<String, SocketChannel> channelEntry : channelGroup.entrySet()) {
            SocketChannel channel = channelEntry.getValue();
            if (channel != socketChannel) {
              doWrite(channel, remoteAddress + ":" + body);
            }
          }
        } else if (readBytes < 0) {
          offLine(socketChannel, remoteAddress);
        }
      } catch (IOException e) {
        offLine(socketChannel, remoteAddress);
      }
    }
  }

  private void offLine(SocketChannel socketChannel, String remoteAddress) {
    try {
      socketChannel.close();
      channelGroup.remove(remoteAddress);
      for (Entry<String, SocketChannel> channelEntry : channelGroup.entrySet()) {
        SocketChannel channel = channelEntry.getValue();
        if (channel != socketChannel) {
          doWrite(channel, remoteAddress + ":" + "is off line");
        }
      }
    } catch (Exception e1) {
      e1.printStackTrace();
    }
  }

  private void handleAccept(SelectionKey key) throws IOException, ClosedChannelException {
    ServerSocketChannel serverChannel = (ServerSocketChannel) key.channel();
    SocketChannel socketChannel = serverChannel.accept();
    socketChannel.configureBlocking(false);
    socketChannel.register(selector, SelectionKey.OP_READ);
    channelGroup.forEach((channelKey, channel) -> {
      try {
        doWrite(channel, socketChannel.getRemoteAddress() + " is on line");
      } catch (IOException e) {
        e.printStackTrace();
      }
    });
    channelGroup.put(socketChannel.getRemoteAddress().toString(), socketChannel);
    System.out.println("new client from " + socketChannel.getRemoteAddress() + " connect to server");
  }

  private void doWrite(SocketChannel socketChannel, String response) throws IOException {
    if (response != null && response.length() > 0) {
      byte[] bytes = response.toLowerCase().getBytes();
      ByteBuffer buffer = ByteBuffer.allocate(bytes.length);
      buffer.put(bytes);
      buffer.flip();
      socketChannel.write(buffer);
    }
  }
}
