package com.liang.springbatch.batchcase;

import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class JobLauncherBean {
  
  @Bean
  JobLauncher getLauncher() {
    return null;
  }

}
