package com.liang.springbatch.batchcase;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.liang.springbatch.Exception.BadItemException;
import com.liang.springbatch.bo.Stock;
import com.liang.springbatch.partitioner.FilePartitioner;

@Component
public class BatchJobHelloWorldPartitioner {
  
  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  FilePartitioner partitioner;
  
  @Autowired
  @Qualifier("partitionReader")
  ItemReader<Stock> reader;
  
  @Autowired
  ItemProcessor<Stock, Stock> processor;
  
  @Autowired
  ItemWriter<Stock> writer;
  
  @Autowired
  @Qualifier("jobInterceptingListener")
  JobExecutionListener jobExecutionListener;
  
  @Autowired
  ThreadPoolTaskExecutor executor;
  
  @Bean(value = "helloWorldJobPartitioner")
  public Job buildHelloWorldJob() {
    Job job = jobBuilderFactory.get("HelloWorldJobPartitioner")
              .incrementer(new RunIdIncrementer())
              .listener(jobExecutionListener)
              .flow(stepMaster())
              .end()
              .build();
    return job;
  }
  
  @Bean
  public Step stepMaster() {
      return stepBuilderFactory.get("HelloWorldStepPartition.master")
              .partitioner("HelloWorldStepPartition", partitioner)
              .step(helloWorldStepPartition())
              .gridSize(2)
//            .taskExecutor(executor)
              .build();
  }

  @Bean
  public Step helloWorldStepPartition() {
      return stepBuilderFactory.get("HelloWorldStepPartition")
              .startLimit(2)
              .allowStartIfComplete(true)
              .<Stock, Stock> chunk(10)
              .reader(reader)
              .processor(processor)
              .writer(writer)
              .faultTolerant()
              .skipLimit(10)
              .skip(BadItemException.class)
//              .retryLimit(3)
//              .retry(BadItemException.class)
//              .taskExecutor(executor)
              .build();
  }
  
  @Bean
  @StepScope
  public FlatFileItemReader<Stock> partitionReader(@Value("#{stepExecutionContext['id']}") Long id) {
      FlatFileItemReader<Stock> reader = new FlatFileItemReader<Stock>();
      String fileName = "stock.csv";
      if (id != null && id > 0) {
        fileName = "stock" + id + ".csv";
      }
      
      reader.setResource(new ClassPathResource(fileName));
      reader.setLineMapper(new DefaultLineMapper<Stock>() {{
          setLineTokenizer(new DelimitedLineTokenizer() {{
              setNames(new String[] { "code", "name", "market" });
          }});
          setFieldSetMapper(new BeanWrapperFieldSetMapper<Stock>() {{
              setTargetType(Stock.class);
          }});
      }});
      return reader;
  }
 
}
