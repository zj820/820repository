package com.liang.network.netty.rpc.model;

import java.io.Serializable;

public class RpcResponse implements Serializable {
  
  /**
   * 
   */
  private static final long serialVersionUID = 6048047058863360541L;
  private String requestId;
  private String error;
  private Object result;
  
  @Override
  public String toString() {
    return String.format("[id:%s; error:%s; result:%s]", requestId, error, result);
  }
  public String getRequestId() {
    return requestId;
  }
  public void setRequestId(String requestId) {
    this.requestId = requestId;
  }
  public String getError() {
    return error;
  }
  public void setError(String error) {
    this.error = error;
  }
  public Object getResult() {
    return result;
  }
  public void setResult(Object result) {
    this.result = result;
  }
  
  

}
