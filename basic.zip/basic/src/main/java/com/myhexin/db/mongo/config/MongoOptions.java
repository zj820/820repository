package com.myhexin.db.mongo.config;


import com.mongodb.DBDecoderFactory;
import com.mongodb.DBEncoderFactory;
import com.mongodb.MongoClientOptions;
import com.mongodb.ReadPreference;
import com.mongodb.WriteConcern;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;

public class MongoOptions
{
  private static final MongoClientOptions DEFAULT_MONGO_OPTIONS = MongoClientOptions.builder().build();
  private String description = DEFAULT_MONGO_OPTIONS.getDescription();
  private int minConnectionsPerHost = DEFAULT_MONGO_OPTIONS.getMinConnectionsPerHost();
  private int connectionsPerHost = DEFAULT_MONGO_OPTIONS.getConnectionsPerHost();
  private int threadsAllowedToBlockForConnectionMultiplier = DEFAULT_MONGO_OPTIONS.getThreadsAllowedToBlockForConnectionMultiplier();
  private int maxWaitTime = DEFAULT_MONGO_OPTIONS.getMaxWaitTime();
  private int maxConnectionIdleTime = DEFAULT_MONGO_OPTIONS.getMaxConnectionIdleTime();
  private int maxConnectionLifeTime = DEFAULT_MONGO_OPTIONS.getMaxConnectionLifeTime();
  private int connectTimeout = DEFAULT_MONGO_OPTIONS.getConnectTimeout();
  private int socketTimeout = DEFAULT_MONGO_OPTIONS.getSocketTimeout();
  private boolean socketKeepAlive = DEFAULT_MONGO_OPTIONS.isSocketKeepAlive();
  private ReadPreference readPreference = DEFAULT_MONGO_OPTIONS.getReadPreference();
  private DBDecoderFactory dbDecoderFactory = DEFAULT_MONGO_OPTIONS.getDbDecoderFactory();
  private DBEncoderFactory dbEncoderFactory = DEFAULT_MONGO_OPTIONS.getDbEncoderFactory();
  private WriteConcern writeConcern = DEFAULT_MONGO_OPTIONS.getWriteConcern();
  private SocketFactory socketFactory = DEFAULT_MONGO_OPTIONS.getSocketFactory();
  private boolean cursorFinalizerEnabled = DEFAULT_MONGO_OPTIONS.isCursorFinalizerEnabled();
  private boolean alwaysUseMBeans = DEFAULT_MONGO_OPTIONS.isAlwaysUseMBeans();
  private int heartbeatFrequency = DEFAULT_MONGO_OPTIONS.getHeartbeatFrequency();
  private int minHeartbeatFrequency = DEFAULT_MONGO_OPTIONS.getMinHeartbeatFrequency();
  private int heartbeatConnectTimeout = DEFAULT_MONGO_OPTIONS.getHeartbeatConnectTimeout();
  private int heartbeatSocketTimeout = DEFAULT_MONGO_OPTIONS.getHeartbeatSocketTimeout();
  private String requiredReplicaSetName = DEFAULT_MONGO_OPTIONS.getRequiredReplicaSetName();
  private boolean ssl;
  private SSLSocketFactory sslSocketFactory;
  
  public MongoClientOptions createMongoClientOptions()
    throws Exception
  {
    SocketFactory socketFactoryToUse = this.ssl ? SSLSocketFactory.getDefault() : this.sslSocketFactory != null ? this.sslSocketFactory : this.socketFactory;
    
    return MongoClientOptions.builder().alwaysUseMBeans(this.alwaysUseMBeans).connectionsPerHost(this.connectionsPerHost).connectTimeout(this.connectTimeout).cursorFinalizerEnabled(this.cursorFinalizerEnabled).dbDecoderFactory(this.dbDecoderFactory).dbEncoderFactory(this.dbEncoderFactory).description(this.description).heartbeatConnectTimeout(this.heartbeatConnectTimeout).heartbeatFrequency(this.heartbeatFrequency).heartbeatSocketTimeout(this.heartbeatSocketTimeout).maxConnectionIdleTime(this.maxConnectionIdleTime).maxConnectionLifeTime(this.maxConnectionLifeTime).maxWaitTime(this.maxWaitTime).minConnectionsPerHost(this.minConnectionsPerHost).minHeartbeatFrequency(this.minHeartbeatFrequency).readPreference(this.readPreference).requiredReplicaSetName(this.requiredReplicaSetName).socketFactory(socketFactoryToUse).socketKeepAlive(this.socketKeepAlive).socketTimeout(this.socketTimeout).threadsAllowedToBlockForConnectionMultiplier(this.threadsAllowedToBlockForConnectionMultiplier).writeConcern(this.writeConcern).build();
  }
  
  public void setDescription(String description)
  {
    this.description = description;
  }
  
  public void setMinConnectionsPerHost(int minConnectionsPerHost)
  {
    this.minConnectionsPerHost = minConnectionsPerHost;
  }
  
  public void setConnectionsPerHost(int connectionsPerHost)
  {
    this.connectionsPerHost = connectionsPerHost;
  }
  
  public void setThreadsAllowedToBlockForConnectionMultiplier(int threadsAllowedToBlockForConnectionMultiplier)
  {
    this.threadsAllowedToBlockForConnectionMultiplier = threadsAllowedToBlockForConnectionMultiplier;
  }
  
  public void setMaxWaitTime(int maxWaitTime)
  {
    this.maxWaitTime = maxWaitTime;
  }
  
  public void setMaxConnectionIdleTime(int maxConnectionIdleTime)
  {
    this.maxConnectionIdleTime = maxConnectionIdleTime;
  }
  
  public void setMaxConnectionLifeTime(int maxConnectionLifeTime)
  {
    this.maxConnectionLifeTime = maxConnectionLifeTime;
  }
  
  public void setConnectTimeout(int connectTimeout)
  {
    this.connectTimeout = connectTimeout;
  }
  
  public void setSocketTimeout(int socketTimeout)
  {
    this.socketTimeout = socketTimeout;
  }
  
  public void setSocketKeepAlive(boolean socketKeepAlive)
  {
    this.socketKeepAlive = socketKeepAlive;
  }
  
  public void setReadPreference(ReadPreference readPreference)
  {
    this.readPreference = readPreference;
  }
  
  public void setWriteConcern(WriteConcern writeConcern)
  {
    this.writeConcern = writeConcern;
  }
  
  public void setSocketFactory(SocketFactory socketFactory)
  {
    this.socketFactory = socketFactory;
  }
  
  public void setHeartbeatFrequency(int heartbeatFrequency)
  {
    this.heartbeatFrequency = heartbeatFrequency;
  }
  
  public void setMinHeartbeatFrequency(int minHeartbeatFrequency)
  {
    this.minHeartbeatFrequency = minHeartbeatFrequency;
  }
  
  public void setHeartbeatConnectTimeout(int heartbeatConnectTimeout)
  {
    this.heartbeatConnectTimeout = heartbeatConnectTimeout;
  }
  
  public void setHeartbeatSocketTimeout(int heartbeatSocketTimeout)
  {
    this.heartbeatSocketTimeout = heartbeatSocketTimeout;
  }
  
  public void setRequiredReplicaSetName(String requiredReplicaSetName)
  {
    this.requiredReplicaSetName = requiredReplicaSetName;
  }
  
  public void setSsl(boolean ssl)
  {
    this.ssl = ssl;
  }
  
  public void setSslSocketFactory(SSLSocketFactory sslSocketFactory)
  {
    this.sslSocketFactory = sslSocketFactory;
  }
}

