package com.liang.network.netty.rpc.service;

public interface Service {
  
  public String service (String name);

}
