package com.liang.network.nio.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class BClient {

  public static void main(String[] args) throws InterruptedException {
    Socket socket = null;
    try {
      socket = new Socket("10.10.20.162", 221);
      BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
      PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
      printWriter.println("how R you? server");
      printWriter.flush();
      socket.shutdownOutput();
      StringBuffer sb = new StringBuffer();
      String message = null;
      while ((message = in.readLine()) != null) {
        sb.append(message);
      }
      System.out.println("got server message" + sb.toString());
    } catch (UnknownHostException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (socket != null && !socket.isClosed()) {
        try {
          socket.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
  }

}
