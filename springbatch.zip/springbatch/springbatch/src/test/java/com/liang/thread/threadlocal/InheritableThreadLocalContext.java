package com.liang.thread.threadlocal;

public class InheritableThreadLocalContext {
  
  InheritableThreadLocal<String> context = new InheritableThreadLocal<String> () {
    @Override
    protected String initialValue() {
      return "iam a context" + Thread.currentThread().getName();
    }
  };
  
  public String getContext() {
    return context.get();
  }
  
  public void setContext(String value) {
    context.set(value);
  }
}
