package com.liang.thread.threadlocal;

public class ThreadLocalContext {
  
  ThreadLocal<String> context = new ThreadLocal<String> () {
    @Override
    protected String initialValue() {
      return "iam a context" + Thread.currentThread().getName();
    }
  };
  
  public String getContext() {
    return context.get();
  }
  
  public void setContext(String value) {
    context.set(value);
  }
}
