package com.liang.network.netty.rpc;

import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

import com.liang.network.netty.rpc.model.RpcRequest;
import com.liang.network.netty.rpc.model.RpcResponse;
import com.liang.network.netty.rpc.service.EntityServiceHello;
import com.liang.network.netty.rpc.service.HelloService;

import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;

public class ServerRequestHandler extends ChannelHandlerAdapter {
  
  
  @Override    
  public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {    
      RpcRequest request = (RpcRequest)msg;  
      Object service = ServiceRigestry.getInstance().getService(request.getClassName());
      
      RpcResponse response = new RpcResponse();
      response.setRequestId(request.getRequestId());
      if (service == null) {
        response.setError("service not exists");
      } else {
        try {
          Method method = service.getClass().getMethod(request.getMethodName(), request.getParameterTypes());  
          Object result = method.invoke(service, request.getParameters());
          response.setResult(result);
        } catch (Exception e) {
          e.printStackTrace();
          response.setError(e.getMessage());
        }
      }
      
      ctx.write(response);  
      ctx.flush();    
      ctx.close();  
  }   
  
  @Override    
  public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {    
       cause.printStackTrace();    
       ctx.close();    
  }    
  
  public static class ServiceRigestry {
    
    private static ServiceRigestry rigestry = new ServiceRigestry();
    private ConcurrentHashMap<String, Object> classMap = null; 
    
    public void rigester(Object service) {
      Class<?>[] interfaces = service.getClass().getInterfaces();
      classMap.put(interfaces[0].getName(), service);
    }
    
    private ServiceRigestry() {
      classMap = new ConcurrentHashMap<String,Object>();
      rigester(new HelloService());
      rigester(new EntityServiceHello());
    }
    
    public static ServiceRigestry getInstance() {
      return rigestry;
    }
    
    @SuppressWarnings("unchecked")
    public <T> T getService(Class<?> clazz) {
      return classMap.contains(clazz.getName()) ?  (T) classMap.get(clazz.getName()) : null;
    }
    
    @SuppressWarnings("unchecked")
    public <T> T getService(String clazz) {
      Object object = classMap.get(clazz);
      return object == null ?  null : (T) object;
    }
  } 

}  
