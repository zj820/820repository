package com.liang.springbatch.partitioner;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

@Component
public class FilePartitioner implements Partitioner {
  
  private static final String PARTITION_KEY = "partition";

  @Override
  public Map<String, ExecutionContext> partition(int gridSize) {
    Map<String, ExecutionContext> contextMap = new HashMap<>();
    ExecutionContext context = new ExecutionContext();
    context.putLong("id", -1L);
    
    ExecutionContext context2 = new ExecutionContext();
    context2.putLong("id", 2L);
    contextMap.put(PARTITION_KEY + 1, context);
    contextMap.put(PARTITION_KEY + 2, context2);
    return contextMap;
  }

}
