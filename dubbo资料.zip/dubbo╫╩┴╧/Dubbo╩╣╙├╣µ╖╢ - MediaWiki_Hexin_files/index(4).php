/* generated javascript */
var skin = 'monobook';
var stylepath = '/wiki/skins';

/* MediaWiki:Common.js */
/* 此处的JavaScript将加载于所有用户每一个页面。 */

/* MediaWiki:Monobook.js */
/* 此处的JavaScript将加载于使用Monobook皮肤的用户 */