package com.myhexin.db.mongo.config;


import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import java.util.Collections;
import java.util.List;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

public class MongoConfig
{
  private String database;
  private String host;
  private Integer port;
  private List<ServerAddress> replicaSet;
  private List<MongoCredential> credentials;
  private MongoOptions mongoOptions;
  
  public ServerAddress createServerAddress()
  {
    if (!StringUtils.hasText(this.host)) {
      this.host = ServerAddress.defaultHost();
    }
    if (this.port == null) {
      return new ServerAddress(this.host);
    }
    return new ServerAddress(this.host, this.port.intValue());
  }
  
  public MongoClient createMongoClient()
    throws Exception
  {
    MongoClientOptions mongoClientOptions = null;
    if (this.mongoOptions == null) {
      mongoClientOptions = MongoClientOptions.builder().build();
    } else {
      mongoClientOptions = this.mongoOptions.createMongoClientOptions();
    }
    if (this.credentials == null) {
      this.credentials = Collections.emptyList();
    }
    if (!CollectionUtils.isEmpty(this.replicaSet)) {
      return new MongoClient(this.replicaSet, this.credentials, mongoClientOptions);
    }
    return new MongoClient(createServerAddress(), this.credentials, mongoClientOptions);
  }
  
  public MongoDbFactory createMongoDbFactory()
    throws Exception
  {
    return new SimpleMongoDbFactory(createMongoClient(), this.database);
  }
  
  public MongoTemplate geMongoTemplate()
    throws Exception
  {
    return new MongoTemplate(createMongoDbFactory());
  }
  
  public String getDatabase()
  {
    return this.database;
  }
  
  public void setDatabase(String database)
  {
    this.database = database;
  }
  
  public String getHost()
  {
    return this.host;
  }
  
  public void setHost(String host)
  {
    this.host = host;
  }
  
  public int getPort()
  {
    return this.port.intValue();
  }
  
  public void setPort(int port)
  {
    this.port = Integer.valueOf(port);
  }
  
  public List<ServerAddress> getReplicaSet()
  {
    return this.replicaSet;
  }
  
  public void setReplicaSet(List<ServerAddress> replicaSet)
  {
    this.replicaSet = replicaSet;
  }
  
  public MongoOptions getMongoOptions()
  {
    return this.mongoOptions;
  }
  
  public void setMongoOptions(MongoOptions mongoOptions)
  {
    this.mongoOptions = mongoOptions;
  }
  
  public List<MongoCredential> getCredentials()
  {
    return this.credentials;
  }
  
  public void setCredentials(List<MongoCredential> credentials)
  {
    this.credentials = credentials;
  }
}

