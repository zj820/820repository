package com.liang.network.netty.rpc.service;

public class HelloService implements Service {

  @Override
  public String service(String name) {
    return "hello " + name;
  }

}
