package com.myhexin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.myhexin.db.mybatis.dao.DomainDao;
import com.myhexin.db.mybatis.dao.FieldDao;

@RestController
@RequestMapping(value="/basic")
public class BasicController {
	
	
	@Autowired
	private DomainDao domainDao;
	
	@Autowired
	private FieldDao fieldDao;
	
	@ResponseBody
	@RequestMapping("/test")
	public String getIndexTag(@RequestParam(value="query") String query){
		int count = domainDao.countDomainSize();
		int fieldCount = fieldDao.countFieldSize();
		return "configFile domainInfo size " + count + "; ontology field size :" + fieldCount;
	}
}
