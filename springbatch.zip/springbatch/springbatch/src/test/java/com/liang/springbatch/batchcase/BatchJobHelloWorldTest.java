package com.liang.springbatch.batchcase;

import java.util.Calendar;
import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.liang.springbatch.Exception.BadItemException;
import com.liang.springbatch.starter.ServiceStart;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ServiceStart.class)
public class BatchJobHelloWorldTest {
  
  @Autowired
  @Qualifier("helloWorldJob")
  Job job;
  
  @Autowired
  JobLauncher jobLauncher;
  
  @Autowired
  JobOperator jobOperator;
  
  @Autowired
  JobExplorer jobExplorer;
  
  private static final Date date = new Date();

  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
  }

  @AfterClass
  public static void tearDownAfterClass() throws Exception {
  }

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void test() {
    Date dateParameter = getDateParameter();
    try {
      launchJob(dateParameter);
    } catch (JobRestartException | JobInstanceAlreadyCompleteException
        | JobParametersInvalidException  | JobExecutionAlreadyRunningException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void launchJob(Date dateParameter) throws JobExecutionAlreadyRunningException, JobRestartException,
      JobInstanceAlreadyCompleteException, JobParametersInvalidException, BadItemException {
        jobLauncher.run(job, new JobParametersBuilder()  
        .addDate("date", dateParameter)  
        .toJobParameters());
  }

  private static Date getDateParameter() {
    
  Calendar c = Calendar.getInstance();
  c.setTimeInMillis(1526991077936L);
  return c.getTime();
    
//    return new Date();
  }

}
