package com.liang.network.netty.rpc.service;

import java.util.Random;

public class EntityServiceHello implements EntityService {

  @Override
  public ServiceResult service(ServiceParameter parameter) {
    ServiceResult result = new ServiceResult();
    long nextLong = new Random(1000).nextLong();
    nextLong = Math.abs(nextLong);
    nextLong = nextLong % 1000;
    result.setTotalTime(nextLong);
    result.setResult("hello " + parameter.getParameter());
    return result;
  }

}
