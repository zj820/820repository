package com.liang.network.netty.rpc;

import com.liang.network.netty.rpc.model.RpcResponse;

import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;

public class ClientResultHandler extends ChannelHandlerAdapter {  
  
  private RpcResponse response;    
    
  public RpcResponse getResponse() {    
  return response;    
}    

  @Override    
  public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {    
      response = (RpcResponse)msg;    
      System.out.println("client接收到服务器返回的消息:" + msg);    
  }    
      
  @Override    
  public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {    
      System.out.println("client exception is general");    
  }    
} 
