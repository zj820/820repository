package com.liang.network.bio;

import java.net.Socket;

public class SocketHandlerThread implements SocketHandler {

  @Override
  public void handle(Socket socket) {
    new Thread(new TimeRunnable(socket)).start();
  }
}
