package com.liang.network.nio.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * bloking server
 * 
 * @author viruser
 *
 */
public class BServer {

  public static void main(String[] args) {
    ServerSocket server = null;
    Socket socket = null;
    try {
      server = new ServerSocket(221);
    } catch (IOException e1) {
      return;
    }

    try {
      while (true) {
        socket = server.accept();
        InputStream stream = socket.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        String message = null;
        StringBuffer sb = new StringBuffer();
        while (true) {
          message = reader.readLine();
          if (message == null) {
            break;
          }

          sb.append(message);
        }
        PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
        System.out.println("got client message " + sb.toString());
        printWriter.println(sb.toString().toLowerCase());
        printWriter.flush();
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        if (!socket.isClosed()) {
          socket.close();
        }
        server.close();
      } catch (IOException e) {
      }
    }
  }

}
