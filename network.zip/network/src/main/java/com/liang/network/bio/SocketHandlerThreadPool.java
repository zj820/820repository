package com.liang.network.bio;

import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SocketHandlerThreadPool implements SocketHandler {

  ExecutorService pool = Executors.newSingleThreadExecutor();

  public void handle(Socket socket) {
    pool.submit(new TimeRunnable(socket));
  }

}
