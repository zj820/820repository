package com.myhexin.db.mybatis.model;

public class Domain {
	private String domainShortCut;
	private String domainIndexPrefix;
	private String domainWithAbs;
	public String getDomainShortCut() {
		return domainShortCut;
	}
	public void setDomainShortCut(String domainShortCut) {
		this.domainShortCut = domainShortCut;
	}
	public String getDomainIndexPrefix() {
		return domainIndexPrefix;
	}
	public void setDomainIndexPrefix(String domainIndexPrefix) {
		this.domainIndexPrefix = domainIndexPrefix;
	}
	public String getDomainWithAbs() {
		return domainWithAbs;
	}
	public void setDomainWithAbs(String domainWithAbs) {
		this.domainWithAbs = domainWithAbs;
	}
	
}
