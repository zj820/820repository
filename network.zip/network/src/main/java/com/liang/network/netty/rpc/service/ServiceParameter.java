package com.liang.network.netty.rpc.service;

import java.io.Serializable;

public class ServiceParameter implements Serializable {
  
  /**
   * 
   */
  private static final long serialVersionUID = 6368444855353162234L;
  private String parameter;

  public ServiceParameter(String parameter) {
    super();
    this.parameter = parameter;
  }

  public String getParameter() {
    return parameter;
  }

  public void setParameter(String parameter) {
    this.parameter = parameter;
  }

}
