package com.liang.network.netty.rpc.service;

import java.io.Serializable;

public class ServiceResult implements Serializable {
  
  /**
   * 
   */
  private static final long serialVersionUID = 9184432164116812751L;
  
  @Override
  public String toString() {
    return String.format("[result:%s; totalTime:%d]", result, totalTime);
  }
  private Long totalTime;
  private String result;
  
  public Long getTotalTime() {
    return totalTime;
  }
  public void setTotalTime(Long totalTime) {
    this.totalTime = totalTime;
  }
  public String getResult() {
    return result;
  }
  public void setResult(String result) {
    this.result = result;
  }
  
  

}
