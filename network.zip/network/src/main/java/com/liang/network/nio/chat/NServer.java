package com.liang.network.nio.chat;

import java.io.IOException;

/**
 * non-bloking server
 * 
 * @author viruser
 *
 */
public class NServer {

  public static void main(String[] args) {
    try {
      new Thread(new NServerTask()).start();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}
